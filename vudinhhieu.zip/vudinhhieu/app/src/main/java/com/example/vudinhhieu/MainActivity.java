package com.example.vudinhhieu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.example.vudinhhieu.R;
import com.example.vudinhhieu.database.DBHelper;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText edName;
    private EditText edQuantity;
    private Button btAdd;
    private Button btView;
    private DBHelper db ;
    private CheckBox checkBox  ;

    @Override
    protected void onCreate(Bundle saveInstanceState){
        super.onCreate(saveInstanceState);
        setContentView(R.layout.activity_main);
        intView();

        db = new DBHelper(this);
        db.getReadableDatabase();
    }
    private void intView(){

            edName = findViewById(R.id.edName);
            edQuantity = findViewById(R.id.edQuantity);

            btAdd = findViewById(R.id.btAdd);
            btAdd.setOnClickListener(this);
            btView = findViewById(R.id.btView);
            btView.setOnClickListener(this);
    }
    @Override
    public void onClick(View v){
        if (v == btAdd){
            onAdd();
        }
        if (v == btView){
            onView();
        }
    }

    private void onView() {

    }

    private void onAdd() {
        if (edName.getText().toString().isEmpty()){
            Toast.makeText(this,"Pleas enter ursename",Toast.LENGTH_LONG).show();
            return;
        }
        if (!checkBox.isChecked()){
            Toast.makeText(this,"pleasr ager rules",Toast.LENGTH_LONG).show();
            return;
        }
        String isAdd = db.addUser(edName.getText().toString(),spinner.get)
    }

}