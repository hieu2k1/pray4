package com.example.vudinhhieu.database;

import android.content.Context;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.vudinhhieu.MainActivity;

public class DBHelper extends SQLiteOpenHelper {

    public static final String DB_NAME = "USER";
    public static final int DB_VERSION = 1;

    public static String TABLE_NAME = "TBL_USER";
    public static String ID = "_id";
    public static String NAME = "name";
    public static String QUANTITY = "quantity";


    public DBHelper(Context context) {
        super(context, DB_NAME. null, DB_VERSION);
    }
}
